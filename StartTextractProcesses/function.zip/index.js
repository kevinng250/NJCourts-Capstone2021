const AWS = require('aws-sdk');

exports.handler = (event, context, callback) => {

    var lambda = new AWS.Lambda();
    files = event.files;
    selectedOptions = event.selectedOptions
    const elasticSearchParams = {
        FunctionName: "textract2esPython",
        InvocationType: "Event",
        Payload: JSON.stringify({
            bucketName : "sanitized-bucket",
            selectedOptions: selectedOptions,
            files: files
        })
      }
      const sentimentAnalysisParams = {
        FunctionName: "SentimentAnalysis",
        InvocationType: "Event",
        Payload: JSON.stringify({
            bucketName : "sanitized-bucket",
            selectedOptions: selectedOptions,
            files: files
        })
      }
    //   const redactionParams = {
    //     FunctionName: "JavaMetaData-test",
    //     InvocationType: "Event",
    //     Payload: JSON.stringify({
    //         bucketName : "sanitized-bucket",
    //         selectedOptions: selectedOptions,
    //         files: wordFiles
    //     })
    //   }
    if(selectedOptions.elasticSearch === 1){
        
        lambda.invoke(elasticSearchParams, (err, data) => {
            if(err){
                return err
            }
            else{
                console.log(data)
                selectedOptions.elasticSearch = 0
            }
        })
    }
    if(selectedOptions.sentimentAnalysis ===1){
        lambda.invoke(sentimentAnalysisParams, (err, data) => {
            if(err){
                return err
            }
            else{
                console.log(data)
                selectedOptions.sentimentAnalysis = 0
            }
        })
    }
    response = {
        files: files,
        selectedOptions = selectedOptions
    }

    //   lambda.invoke()



};